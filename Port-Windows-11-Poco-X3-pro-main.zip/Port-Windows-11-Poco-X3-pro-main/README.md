# NOTICE!

## THE GUIDE HAS NOW BEEN MOVED TO https://github.com/woa-vayu/Port-Windows-11-POCO-X3-Pro

