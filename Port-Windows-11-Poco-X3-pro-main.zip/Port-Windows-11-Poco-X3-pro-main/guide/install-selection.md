<img align="right" src="https://github.com/wormstest/src_vayu_windows/blob/main/2Poco X3 Pro Windows.png" width="350" alt="Windows 11 Running On A Poco X3 Pro">


# Running Windows on the POCO X3 Pro

## Installation

### Select your language

- [English](English/1-partition-en.md)
- [Español](Español/1-particiones-es.md)
- [Русский](Russian/1-partition-ru.md)
- [Українська](Ukrainian/1-partition-uk.md)
- [Lietuvių](Lithuanian/1-partition-lt.md)
