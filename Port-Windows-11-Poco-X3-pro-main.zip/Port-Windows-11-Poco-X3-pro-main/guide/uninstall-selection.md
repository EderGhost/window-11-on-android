<img align="right" src="https://github.com/wormstest/src_vayu_windows/blob/main/2Poco X3 Pro Windows.png" width="350" alt="Windows 11 Running On A Poco X3 Pro">


# Running Windows on the POCO X3 Pro

## Uninstallation

### Select your language

- [English](English/restore-stock-en.md)
- [Español](Español/restaurar-de-fabrica-es.md)
- [Русский](Russian/restore-stock-ru.md)
- [Українська](Ukrainian/restore-stock-uk.md)
- [Lietuvių](Lithuanian/restore-stock-lt.md)
