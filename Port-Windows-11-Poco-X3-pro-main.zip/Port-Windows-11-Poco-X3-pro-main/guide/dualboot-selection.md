<img align="right" src="https://github.com/wormstest/src_vayu_windows/blob/main/2Poco X3 Pro Windows.png" width="350" alt="Windows 11 Running On A Poco X3 Pro">


# Running Windows on the POCO X3 Pro

## Dualbooting Android and Windows seamlessly

### Select your language

- [English](English/dualboot-en.md)
- [Español](Español/dualboot-es.md)
- [Русский](Russian/dualboot-ru.md)
- [Українська](Ukrainian/dualboot-uk.md)
