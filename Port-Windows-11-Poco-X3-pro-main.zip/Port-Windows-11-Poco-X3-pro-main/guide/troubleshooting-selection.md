<img align="right" src="https://github.com/wormstest/src_vayu_windows/blob/main/2Poco X3 Pro Windows.png" width="350" alt="Windows 11 Running On A Poco X3 Pro">


# Running Windows on the POCO X3 Pro

## Troubleshooting Issues

### Select your language

- [English](English/troubleshooting-en.md)
- [Español](Español/solucionar-problemas.md)
- [Русский](Russian/troubleshooting-ru.md)
- [Українська](Ukrainian/troubleshooting-uk.md)
- [Lietuvių](Lithuanian/troubleshooting-lt.md)
